import type { MetadataRoute } from "next";

export const dynamic = "force-static";

export default function robots(): MetadataRoute.Robots {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "https://USERNAME.github.io/REPOSITORY";
  return { rules:{ userAgent:"*", allow:"/" }, sitemap:`${base}/sitemap.xml` };
}
