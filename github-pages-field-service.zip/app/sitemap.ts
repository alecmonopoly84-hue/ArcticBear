import type { MetadataRoute } from "next";
import { landingPages } from "./site-data";

export const dynamic = "force-static";

export default function sitemap(): MetadataRoute.Sitemap {
  const base = process.env.NEXT_PUBLIC_SITE_URL ?? "https://USERNAME.github.io/REPOSITORY";
  return [
    { url:base, changeFrequency:"weekly", priority:1 },
    ...landingPages.map(page => ({ url:`${base}/${page.path}/`, changeFrequency:"monthly" as const, priority:page.kind === "service" || page.kind === "fleet" ? .9 : .75 })),
  ];
}
