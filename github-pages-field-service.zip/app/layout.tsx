import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Техника должна работать — выездной сервис",
  description: "Выездная диагностика и ремонт дорожно-строительной техники в Москве и Московской области.",
  keywords: ["выездной ремонт спецтехники", "ремонт дорожной техники Москва", "сервис спецтехники МО"],
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ru"><body>{children}</body></html>;
}
