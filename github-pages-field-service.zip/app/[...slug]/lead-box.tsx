"use client";

import { FormEvent, useState } from "react";

export default function LeadBox({ subject, fleet = false }: { subject: string; fleet?: boolean }) {
  const [sent, setSent] = useState(false);
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    window.dispatchEvent(new CustomEvent("lead-event", { detail: { event:"form_submit", form:fleet?"fleet":"landing", subject } }));
    setSent(true);
  }
  if (sent) return <div className="inner-success"><span>✓</span><h3>Заявка подготовлена</h3><p>Инженер изучит данные и свяжется с вами. Для реального приёма обращений требуется подключить CRM и контакты диспетчерской.</p></div>;
  return <form className="inner-form" id="top-form" onSubmit={submit}>
    <p>{fleet ? "Рассчитать модель обслуживания" : "Передать задачу инженеру"}</p>
    <h3>{fleet ? "Расскажите о парке" : `Нужен ${subject}?`}</h3>
    {fleet ? <><label>Компания<input required name="company" placeholder="Название компании" /></label><label>Парк техники<input required name="fleet" placeholder="Количество, типы и бренды" /></label></> : <><label>Техника и модель<input required name="machine" placeholder="Например, XCMG LW500" /></label><label>Симптом<textarea required name="problem" placeholder="Что произошло с машиной?" /></label><label className="mini-upload">Фото / видео<input type="file" accept="image/*,video/*" /></label></>}
    <label>Телефон<input required name="phone" inputMode="tel" placeholder="+7 ___ ___-__-__" /></label>
    <button className="button primary full" type="submit">{fleet ? "Обсудить сервисный договор" : "Вызвать сервисную бригаду"}</button>
    <small>Отправляя форму, вы соглашаетесь на обработку персональных данных.</small>
  </form>;
}
