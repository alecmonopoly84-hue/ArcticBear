import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { landingMap, landingPages } from "../site-data";
import LeadBox from "./lead-box";
import BrandMark from "../brand-mark";

export const dynamicParams = false;
export function generateStaticParams() { return landingPages.map(page => ({ slug: page.path.split("/") })); }

export async function generateMetadata({ params }: { params: Promise<{slug:string[]}> }): Promise<Metadata> {
  const { slug } = await params;
  const page = landingMap.get(slug.join("/"));
  if (!page) return {};
  return { title:`${page.title} | ABService`, description:page.lead };
}

const flow = [
  ["01","Заявка","Фиксируем технику, модель, объект и симптомы."],
  ["02","Материалы","Смотрим фото, видео, шильдик и коды ошибок."],
  ["03","Подготовка","Определяем маршрут диагностики и оснащение."],
  ["04","Выезд","Диагностика, согласование, ремонт и проверка."],
];

export default async function Landing({ params }: { params: Promise<{slug:string[]}> }) {
  const { slug } = await params;
  const page = landingMap.get(slug.join("/"));
  if (!page) notFound();
  const isFleet = page.kind === "fleet";
  const isLegal = page.kind === "legal";
  return <main className="inner-page">
    <header className="site-header inner-header">
      <Link className="brand" href="/" aria-label="ABService — на главную"><BrandMark priority /><span><strong>ABService</strong><small>выездной сервис</small></span></Link>
      <nav className="desktop-nav"><Link href="/service/">Выездной сервис</Link><Link href="/repair/">Ремонт</Link><Link href="/diagnostics/">Диагностика</Link><Link href="/fleet-service/">Для парка</Link></nav>
      <div className="header-contact"><Link href="/contacts/">[ТЕЛЕФОН]</Link><span>Москва и Московская область</span></div>
    </header>

    <section className="inner-hero">
      <div className="inner-hero-copy"><div className="breadcrumbs"><Link href="/">Главная</Link><span>—</span><span>{page.eyebrow}</span></div><p className="eyebrow light"><i /> {page.eyebrow}</p><h1>{page.title}</h1><p>{page.lead}</p>{!isLegal&&<div className="inner-hero-points"><span>Москва и МО</span><span>Выезд на объект</span><span>[ГАРАНТИЯ]</span></div>}</div>
      {!isLegal ? <LeadBox subject={page.subject} fleet={isFleet} /> : <aside className="legal-status"><span>!</span><h3>Требуются реквизиты</h3><p>До публикации юридического текста необходимо подтвердить оператора данных, используемую CRM, состав полей и срок хранения.</p></aside>}
    </section>

    {isLegal ? <section className="section legal-copy"><h2>Структура документа</h2>{page.symptoms.map((item,i)=><article key={item}><span>{String(i+1).padStart(2,"0")}</span><h3>{item}</h3><p>[ТЕКСТ ТРЕБУЕТ ЮРИДИЧЕСКИХ ДАННЫХ И ПРОВЕРКИ]</p></article>)}</section> : <>
      <section className="inner-proof"><div><b>Ремонт на объекте</b><span>минимум времени на перевозку</span></div><div><b>Предварительная диагностика</b><span>по симптомам и материалам</span></div><div><b>Согласование до работ</b><span>причина, состав и стоимость</span></div></section>

      <section className="section inner-symptoms"><div className="section-heading"><p className="eyebrow"><i /> Типовые задачи</p><h2>{page.kind === "cases" ? "Что должен содержать каждый кейс" : `Когда нужен ${page.subject}`}</h2></div><div className="symptom-list">{page.symptoms.map((item,i)=><div key={item}><span>{String(i+1).padStart(2,"0")}</span><b>{item}</b></div>)}</div></section>

      {page.kind === "cases" ? <section className="section inner-case"><div className="case-photo">ФОТО РЕАЛЬНОГО РЕМОНТА<br/>К ПОЛУЧЕНИЮ</div><div><p className="eyebrow"><i /> Шаблон кейса</p><h2>XCMG LW500 — потеря тяги</h2><p className="placeholder-warning">Демонстрационный placeholder. Факты и фотографии не придуманы.</p><dl><div><dt>Объект</dt><dd>[ТРЕБУЕТ ДАННЫХ]</dd></div><div><dt>Диагностика</dt><dd>[ТРЕБУЕТ ДАННЫХ]</dd></div><div><dt>Причина</dt><dd>[ТРЕБУЕТ ДАННЫХ]</dd></div><div><dt>Результат</dt><dd>Техника возвращена в работу [ПОДТВЕРДИТЬ]</dd></div></dl></div></section> : page.kind === "area" ? <section className="section area-map"><div><p className="eyebrow"><i /> Карта выезда</p><h2>Условия зависят от удалённости объекта</h2><p>В интерфейсе предусмотрены четыре зоны. Тарифы, время и предельная удалённость заполняются после подтверждения диспетчерской модели.</p></div><div className="map-rings"><span>Москва</span><i>до 30 км</i><b>30–60 км</b><em>&gt;60 км</em></div></section> : <section className="section inner-value"><div><p className="eyebrow light"><i /> Результат для клиента</p><h2>{isFleet ? "Управляемое обслуживание вместо разрозненных ремонтов" : "Сначала причина. Потом согласованное решение."}</h2></div><div className="value-cards"><article><span>01</span><h3>{isFleet?"Единое окно":"Меньше неопределённости"}</h3><p>{isFleet?"Плановое ТО, аварийные заявки, запчасти и история работ в одной модели.":"Инженер начинает с фактов: модель, симптомы, коды и параметры."}</p></article><article><span>02</span><h3>{isFleet?"Регламент и SLA":"Подготовленный выезд"}</h3><p>{isFleet?"Приоритеты, сроки реакции и отчётность фиксируются в сервисной модели.":"Состав инструмента и вероятных деталей формируется до прибытия."}</p></article><article><span>03</span><h3>{isFleet?"Экономика парка":"Контроль решения"}</h3><p>{isFleet?"Считаем простои, повторные обращения и стоимость обслуживания единицы.":"Причина, работы и стоимость согласуются до ремонта."}</p></article></div></section>}

      <section className="section inner-process"><div className="section-heading"><p className="eyebrow"><i /> Как работаем</p><h2>От обращения до возвращения техники в работу</h2></div><div className="process-grid">{flow.map(([n,title,text])=><article key={n}><span>{n}</span><h3>{title}</h3><p>{text}</p></article>)}</div></section>

      <section className="section inner-price"><div><p className="eyebrow"><i /> Стоимость</p><h2>База расчёта без скрытых обещаний</h2><p>Точная цена зависит от модели, неисправности, удалённости объекта и объёма работ.</p></div><div><span>Выезд</span><b>от [СТОИМОСТЬ] ₽</b><span>Диагностика</span><b>от [СТОИМОСТЬ] ₽</b><span>Нормо-час</span><b>[СТОИМОСТЬ] ₽</b></div></section>

      <section className="section inner-faq"><div className="section-heading"><p className="eyebrow"><i /> Вопросы до выезда</p><h2>Коротко по делу</h2></div><div className="faq-list"><details><summary>Что передать инженеру?<span>+</span></summary><p>Тип, марку и модель техники, адрес, симптомы и телефон. По возможности — фото панели, шильдика и места неисправности.</p></details><details><summary>Можно ли получить оценку заранее?<span>+</span></summary><p>По описанию можно определить базовый формат выезда. Точная стоимость ремонта формируется после диагностики.</p></details><details><summary>Какие документы предоставляются?<span>+</span></summary><p>Договор, закрывающие документы и условия гарантии: [ТРЕБУЕТ ДАННЫХ].</p></details></div></section>

      <section className="inner-bottom"><div><p className="eyebrow light"><i /> Следующий шаг</p><h2>{isFleet?"Обсудим модель обслуживания вашего парка":"Передайте модель и симптом — инженер начнёт подготовку"}</h2></div><a className="button primary" href="#top-form">{isFleet?"Рассчитать сервис":"Вызвать сервисную бригаду"}</a></section>
    </>}

    <footer><div className="brand"><BrandMark /><span><strong>ABService</strong><small>выездной сервис</small></span></div><p>Москва и Московская область<br/>[ЮРИДИЧЕСКИЕ РЕКВИЗИТЫ]</p><nav><Link href="/service-area/">Зона выезда</Link><Link href="/contacts/">Контакты</Link><Link href="/privacy/">Политика данных</Link></nav></footer>
    {!isLegal&&<div className="mobile-cta"><Link href="/contacts/">Позвонить</Link><a href="#top-form">Вызвать бригаду</a><a href="#top-form">Отправить фото</a></div>}
  </main>;
}
