"use client";

import { FormEvent, useEffect, useState } from "react";
import Link from "next/link";

const symptoms = ["Не заводится", "Не едет / нет тяги", "Не работает гидравлика", "Ошибка на панели", "Перегрев", "Течь или шум"];
const machines = ["Экскаваторы", "Экскаваторы-погрузчики", "Фронтальные погрузчики", "Бульдозеры", "Автогрейдеры", "Катки", "Асфальтоукладчики", "Дорожные фрезы", "Мини-погрузчики", "Телескопические погрузчики", "Другая спецтехника"];
const machineSlugs = ["excavators", "backhoe-loaders", "wheel-loaders", "bulldozers", "graders", "rollers", "pavers", "", "skid-steers", "telehandlers", ""];
const systems = ["Двигатель", "Гидравлика", "Электрика", "Топливная система", "Трансмиссия и КПП", "Мосты и редукторы", "Ходовая", "Тормозная система", "Электронные системы", "РВД"];
const brands = ["XCMG", "SANY", "LiuGong", "SDLG / LGCE", "Shantui", "Zoomlion", "Lonking", "Komatsu", "Caterpillar", "Volvo CE", "Hitachi", "JCB", "Develon", "Hyundai", "Bomag", "Hamm", "Ammann", "Wirtgen"];
const brandSlugs = ["xcmg", "sany", "liugong", "sdlg", "shantui", "zoomlion", "", "komatsu", "caterpillar", "volvo-ce", "hitachi", "jcb", "develon", "hyundai", "bomag", "hamm", "ammann", "wirtgen"];

type LeadMode = "emergency" | "diagnostic" | "fleet";

function track(event: string, data: Record<string, string> = {}) {
  if (typeof window !== "undefined") window.dispatchEvent(new CustomEvent("lead-event", { detail: { event, ...data } }));
}

export default function Home() {
  const [symptom, setSymptom] = useState("");
  const [modal, setModal] = useState<LeadMode | null>(null);
  const [step, setStep] = useState(1);
  const [sent, setSent] = useState(false);

  useEffect(() => {
    document.body.style.overflow = modal ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [modal]);

  function openLead(mode: LeadMode) {
    setModal(mode); setStep(1); setSent(false); track("form_start", { form: mode });
  }
  function closeLead() { setModal(null); setStep(1); setSent(false); }
  function submitLead(event: FormEvent<HTMLFormElement>) {
    event.preventDefault(); setSent(true); track("form_submit", { form: modal ?? "unknown", symptom });
  }

  return <main>
    <header className="site-header">
      <a className="brand" href="#top" aria-label="Техника работает — на главную"><span className="brand-mark">ТР</span><span><strong>ТЕХНИКА РАБОТАЕТ</strong><small>выездной сервис</small></span></a>
      <nav className="desktop-nav" aria-label="Основная навигация"><a href="#repair">Что ремонтируем</a><a href="#process">Как работаем</a><a href="#prices">Стоимость</a><Link href="/fleet-service/">Для парка</Link></nav>
      <div className="header-contact"><a href="#contacts" data-analytics="phone_click">[ТЕЛЕФОН]</a><span>Москва и Московская область</span></div>
    </header>

    <section className="hero" id="top">
      <div className="hero-copy">
        <p className="eyebrow light"><i /> Выездной сервис на объекте</p>
        <h1>Возвращаем дорожную технику <em>в работу</em></h1>
        <p className="hero-lead">Диагностика и ремонт экскаваторов, погрузчиков, бульдозеров, катков и другой спецтехники в Москве и Московской области.</p>
        <div className="hero-actions"><button className="button primary" onClick={() => openLead("emergency")}>Вызвать сервисную бригаду</button><button className="button outline-light" onClick={() => openLead("diagnostic")}>Отправить фото поломки</button></div>
        <ul className="proof-list"><li><b>Ремонт на объекте</b><span>без лишней транспортировки машины</span></li><li><b>Подготовленный выезд</b><span>изучаем модель, симптомы и фото заранее</span></li><li><b>Понятный результат</b><span>диагностика, согласование, документы</span></li></ul>
      </div>
      <aside className="dispatch-card" aria-label="Быстрая заявка">
        <div className="live-status"><i /> Принимаем обращения</div><p className="micro-title">Быстрая заявка</p><h2>Что случилось с техникой?</h2><p>Выберите симптом — инженер поймёт, с чего начать диагностику.</p>
        <div className="symptom-grid">{symptoms.map(item => <button key={item} className={symptom === item ? "symptom active" : "symptom"} onClick={() => { setSymptom(item); track("problem_select", { value:item }); }}>{item}</button>)}</div>
        <button className="button dark full" onClick={() => openLead("diagnostic")}>Продолжить заявку <span>→</span></button><small>Телефон, техника и проблема — меньше минуты.</small>
      </aside>
    </section>

    <section className="trust-strip" aria-label="Параметры сервиса"><div><span>01</span><b>Москва + МО</b><small>зона выездного сервиса</small></div><div><span>02</span><b>Диагностика на месте</b><small>до начала ремонта</small></div><div><span>03</span><b>Фото и видео до выезда</b><small>готовим инструмент и детали</small></div><div><span>04</span><b>[ВРЕМЯ ВЫЕЗДА]</b><small>после квалификации заявки</small></div></section>

    <section className="section intro" id="repair"><div className="section-heading"><p className="eyebrow"><i /> Ремонтируем на объекте</p><h2>Одна заявка — от симптома до запуска машины</h2></div><p className="section-lead">Передайте модель и признаки неисправности. Инженер уточнит задачу, подготовит диагностический маршрут и состав оснащения на выезд.</p></section>

    <section className="catalog section-tight">
      <div className="catalog-column"><div className="catalog-title"><span>01</span><h3>Какую технику ремонтируем</h3></div><div className="machine-grid">{machines.map((item, i) => <Link href={machineSlugs[i] ? `/repair/${machineSlugs[i]}/` : "/repair/"} key={item}><span>{String(i+1).padStart(2,"0")}</span>{item}<b>↗</b></Link>)}</div></div>
      <div className="catalog-column systems-column"><div className="catalog-title"><span>02</span><h3>Какие системы диагностируем</h3></div><div className="system-list">{systems.map(item => <span key={item}>{item}</span>)}</div><button className="text-action" onClick={() => openLead("diagnostic")}>Не нашли симптом? Опишите инженеру <b>→</b></button></div>
    </section>

    <section className="downtime section"><div className="section-heading inverse"><p className="eyebrow light"><i /> Экономика простоя</p><h2>Выездной сервис сокращает путь до решения</h2></div><div className="economy-grid"><article><span>01</span><h3>Без перевозки «по умолчанию»</h3><p>Диагностика начинается на объекте. Эвакуация нужна только тогда, когда ремонт невозможно выполнить на месте.</p></article><article><span>02</span><h3>Инженер готовится заранее</h3><p>Фото панели, шильдика и места неисправности помогают взять подходящий инструмент и определить вероятные детали.</p></article><article><span>03</span><h3>Решение согласуется до работ</h3><p>После диагностики вы понимаете причину, состав работ и ориентир по затратам до начала ремонта.</p></article></div><button className="button primary" onClick={() => openLead("diagnostic")}>Передать данные о неисправности</button></section>

    <section className="process section" id="process"><div className="section-heading"><p className="eyebrow"><i /> Как проходит заявка</p><h2>Подготовка начинается ещё до выезда</h2></div><div className="process-grid"><article><span>01</span><h3>Фиксируем задачу</h3><p>Тип и модель техники, местоположение, симптом и срочность.</p></article><article><span>02</span><h3>Смотрим материалы</h3><p>Фото, видео, код ошибки, панель приборов и шильдик.</p></article><article><span>03</span><h3>Готовим выезд</h3><p>Маршрут диагностики, инструмент, расходники и вероятные детали.</p></article><article><span>04</span><h3>Возвращаем в работу</h3><p>Диагностика, согласование, ремонт, проверка и документы.</p></article></div></section>

    <section className="workshop section"><div className="workshop-visual" aria-label="Место для фотографии мобильной мастерской"><div className="photo-label">ФОТО К ПОЛУЧЕНИЮ</div><div className="van-shape"><i /><i /><span /></div><p>Нужна реальная фотография сервисного автомобиля в раскрытом виде</p></div><div className="workshop-copy"><p className="eyebrow"><i /> Мобильная мастерская</p><h2>Не просто механик. Подготовленное рабочее место на объекте.</h2><div className="equipment-list"><span>Диагностическое оборудование</span><span>Специализированный инструмент</span><span>Компрессор и генератор</span><span>Сварочное оборудование</span><span>Гидравлический инструмент</span><span>Расходные материалы и ЗЧ</span></div><p className="note">Состав оснащения должен быть подтверждён заказчиком. Неподтверждённые позиции до публикации не заявляются.</p></div></section>

    <section className="prices section" id="prices"><div className="section-heading"><p className="eyebrow"><i /> Прозрачная база расчёта</p><h2>Стоимость понятна до начала ремонта</h2></div><div className="price-layout"><div className="price-list">{["Выезд сервисной бригады","Диагностика","Нормо-час","Компьютерная диагностика","Выезд за МКАД"].map((item,i)=><div key={item}><span>{String(i+1).padStart(2,"0")}</span><b>{item}</b><strong>{i===4?"[СТОИМОСТЬ] ₽/км":"от [СТОИМОСТЬ] ₽"}</strong></div>)}</div><aside><h3>Получите предварительную оценку</h3><p>Точная стоимость зависит от модели техники, неисправности, удалённости объекта и объёма работ.</p><button className="button dark full" onClick={() => openLead("diagnostic")}>Описать неисправность</button><small>Не заменяет диагностику на объекте.</small></aside></div></section>

    <section className="cases section"><div className="section-heading"><p className="eyebrow"><i /> Реальные ремонты</p><h2>Компетенцию показывают кейсы, а не обещания</h2></div><div className="case-placeholder"><div><span>КЕЙС 01</span><h3>Фронтальный погрузчик — потеря тяги</h3><p>Демонстрационный шаблон. Здесь будут: модель, объект, диагностика, причина, состав работ, запчасти, время восстановления и результат.</p></div><div className="case-photo">ФОТО РЕМОНТА<br/>К ПОЛУЧЕНИЮ</div></div><Link className="text-action" href="/cases/">Структура раздела «Реальные ремонты» <b>↗</b></Link></section>

    <section className="brands section-tight"><div className="brands-head"><p className="eyebrow"><i /> Марки техники</p><h2>Ремонтируем технику российских, китайских, европейских и азиатских брендов</h2><p>Не заявляем официальный статус без подтверждения.</p></div><div className="brand-grid">{brands.map((item,i) => <Link key={item} href={brandSlugs[i] ? `/brands/${brandSlugs[i]}/` : "/repair/"}>{item}<span>↗</span></Link>)}</div></section>

    <section className="fleet section"><div><p className="eyebrow light"><i /> Для корпоративного парка</p><h2>Не только аварийные выезды. Управляемая модель обслуживания парка.</h2><p>Плановое ТО, аварийная поддержка, история ремонтов, запчасти, регламент и SLA — через единое окно.</p></div><div className="fleet-actions"><button className="button primary" onClick={() => openLead("fleet")}>Рассчитать сервис для парка</button><Link href="/fleet-service/">Подробнее о модели сервиса →</Link></div></section>

    <section className="faq section"><div className="section-heading"><p className="eyebrow"><i /> Частые вопросы</p><h2>До выезда</h2></div><div className="faq-list">{[["Какие данные нужны для заявки?","Тип и модель техники, адрес объекта, симптомы, телефон. Фото панели, шильдика и места неисправности ускорят подготовку."],["Можно ли понять стоимость заранее?","После первичного описания инженер даст ориентир по выезду и диагностике. Точная стоимость ремонта определяется после осмотра и согласуется до работ."],["Работаете ли вы за пределами МКАД?","Да, зона выезда — Москва и Московская область. Тариф и максимальная удалённость: [ТРЕБУЕТ ДАННЫХ]."],["Есть ли гарантия?","Условия гарантии на работы и установленные детали: [ТРЕБУЕТ ДАННЫХ]."]].map(([q,a])=><details key={q}><summary>{q}<span>+</span></summary><p>{a}</p></details>)}</div></section>

    <section className="final-cta section" id="contacts"><div><p className="eyebrow light"><i /> Диспетчерская</p><h2>Техника стоит? Передайте задачу инженеру.</h2><p>Модель, симптом и фото — достаточно, чтобы начать предварительную диагностику.</p></div><div><a className="contact-phone" href="#">[ТЕЛЕФОН]</a><button className="button primary" onClick={() => openLead("emergency")}>Вызвать сервисную бригаду</button><span>Telegram [ССЫЛКА] · WhatsApp [ССЫЛКА]</span></div></section>

    <footer><div className="brand"><span className="brand-mark">ТР</span><span><strong>ТЕХНИКА РАБОТАЕТ</strong><small>выездной сервис</small></span></div><p>Москва и Московская область<br/>[ЮРИДИЧЕСКИЕ РЕКВИЗИТЫ]</p><nav><Link href="/service-area/">Зона выезда</Link><Link href="/contacts/">Контакты</Link><Link href="/privacy/">Политика данных</Link></nav></footer>

    {modal && <div className="modal-backdrop" role="presentation" onMouseDown={closeLead}><section className="lead-panel" role="dialog" aria-modal="true" aria-labelledby="lead-title" onMouseDown={e=>e.stopPropagation()}><button className="modal-close" aria-label="Закрыть" onClick={closeLead}>×</button>{!sent ? <><div className="step-line"><span style={{width:`${step*33.34}%`}} /></div><p className="micro-title">{modal === "fleet" ? "Сервис для парка" : "Заявка на выезд"} · шаг {step} из 3</p><form onSubmit={submitLead}><h2 id="lead-title">{step===1 ? (modal==="fleet"?"Расскажите о парке":"Какая техника неисправна?") : step===2 ? "Что произошло?" : "Как с вами связаться?"}</h2>{step===1 && <div className="form-step"><label>{modal==="fleet"?"Компания":"Тип техники"}<input required name="machine" placeholder={modal==="fleet"?"Название компании":"Например, фронтальный погрузчик"}/></label><label>{modal==="fleet"?"Количество единиц":"Марка и модель"}<input name="model" placeholder={modal==="fleet"?"Например, 18":"Например, XCMG LW500"}/></label><button type="button" className="button dark full" onClick={()=>setStep(2)}>Продолжить →</button></div>}{step===2 && <div className="form-step"><label>{modal==="fleet"?"Состав парка и объекты":"Симптом или код ошибки"}<textarea required name="problem" defaultValue={symptom} placeholder="Опишите проблему своими словами"/></label>{modal!=="fleet"&&<label className="upload">Фото или видео<input type="file" accept="image/*,video/*" multiple onChange={()=>track("photo_attach")}/><span>Добавить материалы с телефона</span></label>}<div className="step-buttons"><button type="button" className="button ghost" onClick={()=>setStep(1)}>Назад</button><button type="button" className="button dark" onClick={()=>setStep(3)}>Продолжить →</button></div></div>}{step===3 && <div className="form-step"><label>Телефон<input required name="phone" inputMode="tel" placeholder="+7 ___ ___-__-__"/></label><label>Имя<input name="name" autoComplete="name" placeholder="Как к вам обращаться"/></label><button className="button primary full" type="submit">Передать инженеру</button><small>Отправляя форму, вы соглашаетесь на обработку персональных данных.</small></div>}</form></> : <div className="success"><span>✓</span><h2>Заявка подготовлена</h2><p>Сервисный инженер изучит информацию и свяжется с вами для предварительной диагностики и подготовки к выезду.</p><small>В рабочей версии здесь подключается CRM и уведомление диспетчера.</small><button className="button dark full" onClick={closeLead}>Закрыть</button></div>}</section></div>}
    <div className="mobile-cta"><a href="#contacts">Позвонить</a><button onClick={()=>openLead("emergency")}>Вызвать бригаду</button><button onClick={()=>openLead("diagnostic")}>Отправить фото</button></div>
  </main>;
}
