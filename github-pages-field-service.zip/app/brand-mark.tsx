import Image from "next/image";
import bearLogo from "../public/abservice-polar-bear.png";

export default function BrandMark({ priority = false }: { priority?: boolean }) {
  return <span className="brand-mark" aria-hidden="true"><Image src={bearLogo} alt="" priority={priority} /></span>;
}
