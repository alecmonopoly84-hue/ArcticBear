import type { NextConfig } from "next";

const rawBasePath = process.env.BASE_PATH ?? "";
const cleanBasePath = rawBasePath.replace(/^\/+|\/+$/g, "");
const basePath = cleanBasePath ? `/${cleanBasePath}` : "";

const nextConfig: NextConfig = {
  output: "export",
  trailingSlash: true,
  basePath,
  assetPrefix: basePath || undefined,
  images: { unoptimized: true },
  turbopack: { root: process.cwd() },
};

export default nextConfig;
