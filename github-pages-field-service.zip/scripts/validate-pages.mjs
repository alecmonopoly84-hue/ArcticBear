import { existsSync, readFileSync, readdirSync } from "node:fs";
import { join } from "node:path";

const root = new URL("../out/", import.meta.url).pathname;
const required = [
  "index.html",
  "repair/index.html",
  "repair/excavators/index.html",
  "brands/xcmg/index.html",
  "fleet-service/index.html",
  "cases/index.html",
  "service-area/index.html",
  "sitemap.xml",
  "robots.txt",
  ".nojekyll",
];

const missing = required.filter(file => !existsSync(join(root, file)));
if (missing.length) throw new Error(`Missing GitHub Pages files: ${missing.join(", ")}`);

const files = readdirSync(root, { recursive:true, withFileTypes:true });
const htmlCount = files.filter(entry => entry.isFile() && entry.name === "index.html").length;
if (htmlCount < 40) throw new Error(`Expected at least 40 exported pages, found ${htmlCount}`);

const homepage = readFileSync(join(root, "index.html"), "utf8");
if (!homepage.includes("ABService")) throw new Error("Homepage content was not exported");

const sitemap = readFileSync(join(root, "sitemap.xml"), "utf8");
if (sitemap.includes("chatgpt.site")) throw new Error("Sitemap still points to the ChatGPT Sites domain");

console.log(`Validated ${htmlCount} static pages for GitHub Pages.`);
